#!/bin/bash
java -Xmx1024M -Xms1024M -jar paper-1.12.2.jar nogui

#!/bin/bash
java -Xmx512M -Xms512M -jar BungeeCord.jar
